<?php
    session_start();
    if(!isset($_SESSION['username'])){
        // user is not logged in, redirect to login page
        header('Location: login.php');
        exit;
    }

    require_once('database.php');
    if(isset($_GET['id'])){
        $id = $_GET['id'];
        $database->delete($id);
        header('Location: view.php');
    }
?>