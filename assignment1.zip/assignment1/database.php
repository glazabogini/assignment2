<?php
  class Database{
    private $connection;

    function __construct(){
      $this->connect_db();
    }

    public function connect_db(){
      $this->connection = mysqli_connect('localhost', 'root', '', 'assignment1');
      if(mysqli_connect_error()){
        die("Database Connection Failed" . mysqli_connect_error() . mysqli_connect_error());
      }
    }

    public function create($fname, $lname, $age, $instrument, $bname, $image){
      $sql = "INSERT INTO school_band (fname, lname, age, instrument, bname, image) VALUES ('$fname', '$lname', '$age', '$instrument', '$bname', '$image')";
      $res = mysqli_query($this->connection, $sql);
      if($res){
          return true;
      }
      else{
          return false;
      }
    }
    
    public function createUser($username, $password){
      $sql = "INSERT INTO users (username, pword) VALUES ('$username', '$password')";
      $res = mysqli_query($this->connection, $sql);
      if($res){
          return true;
      }
      else{
          return false;
      } 
    }

    public function checkUser($username, $password){
      $stmt = $this->connection->prepare("SELECT * FROM users WHERE username = ? AND pword = ?");
      $stmt->bind_param('ss', $username, $password);
  
      $stmt->execute();
  
      $result = $stmt->get_result();
  
      if ($result->num_rows > 0){
          return true;
      } else {
          return false;
      }
    }

    public function update($id, $fname, $lname, $age, $instrument, $bname, $image){
      $sql = "UPDATE school_band SET fname='$fname', lname='$lname', age='$age', instrument='$instrument', bname='$bname', image='$image' WHERE id=$id";
      $res = mysqli_query($this->connection, $sql);
      if($res){
          return true;
      }
      else{
          return false;
      }
    }
    
    public function delete($id){
      $sql = "DELETE FROM school_band WHERE id=$id";
      $res = mysqli_query($this->connection, $sql);
      if($res){
          return true;
      }
      else{
          return false;
      }
    }
  

    public function read($id=null){
		$sql = "SELECT * FROM school_band";
		if($id){
            $sql .= " WHERE id=$id";
        }
 		$res = mysqli_query($this->connection, $sql);
 		return $res;
	  }
  }
  $database = new Database();
?>
