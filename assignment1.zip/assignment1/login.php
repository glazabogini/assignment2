<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login Page</title>
    <meta name="author" content="Michael Nikishin">
    <meta name="description" content="School Music Band Database Login">
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <header>
        <h1>Login to School Music Bands</h1>
        <img class = "logo" src = "images/logo.png" alt = "logo">
        <nav class = "global-nav">
            <ul>
                <li><a href = "./index.php" title = "Go to home page">Home</a></li>
                <li><a href = "./view.php" title = "View the table">View Table</a></li>
                <li><a href = "./register.php" title = "Go to the register page">Register</a></li>
                <li><a href = "./login.php" title = "Go to the login page">Login</a></li>
            </ul>
        </nav>   
    </header>
    <main>
        <h1>Login</h1>
        <form action="login.php" method="post">
            <fieldset class = "big-border">
                <legend>Please enter your login details:</legend>
                <input type="text" placeholder="Enter your username" name="username" required>
                <input type="password" placeholder="and password" name="password" required>
            </fieldset>
            <input type="submit">
            <input type="reset" value="Clear">
        </form>
        
        <?php
        session_start();
        require_once('database.php');

        $message = '';

        if(isset($_POST['username']) && isset($_POST['password'])){
            $username = trim($_POST['username']);
            $password = trim($_POST['password']);

            $password = hash('sha512', $password);

            $password = substr($password, 0, 20);

            $res = $database->checkUser($username, $password);
            if($res){
                $_SESSION['username'] = $username;
                header("Location: view.php");
            }else{
                $message = "Incorrect username or password.";
            }
        }
        if(!empty($message)): ?>
            <p> <?= $message ?></p>
        <?php endif;
        ?>
    </main>
    <footer>
        <p><small>Music Is Fun!</small></p>
    </footer>
</body>
</html>
